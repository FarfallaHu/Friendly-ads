import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:io';

class Adstate {
  Adstate({
    @required this.initialization,
  });
  Future<InitializationStatus>? initialization;
  String get bannerAdUnitId {
    return "ca-app-pub-5785322248556811/9457730925";
  }
}
