import 'package:fan_page/screens/home_screen.dart';
import 'package:fan_page/screens/login_screen.dart';
import 'package:fan_page/screens/splash_screen.dart';
import 'package:flutter/material.dart';
import 'screens/admin_message.dart';
import 'screens/register_screen.dart';
import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // FirebaseAppCheck firebaseAppCheck = FirebaseAppCheck.instance;
  // // firebaseAppCheck.installAppCheckProviderFactory(
  // //     SafetyNetAppCheckProviderFactory.getInstance());
  try {
    MobileAds.instance.initialize();
  } catch (e) {
    print('MobileAdsException$e');
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Friendly',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/splash',
      routes: {
        '/home': (context) => Home(),
        '/login': (context) => LogIn(),
        '/register': (context) => Register(),
        '/admin': (context) => AdminMessage(title: "Friendly"),
        '/splash': (context) => Splash(),
      },
    );
  }
}
