import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:uuid/uuid.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:async';

class AdminMessage extends StatefulWidget {
  AdminMessage({Key? key, required this.title}) : super(key: key);

  final String title;
  @override
  _AdminMessageState createState() => _AdminMessageState();
}

class _AdminMessageState extends State<AdminMessage> {
  final _auth = FirebaseAuth.instance;
  late User loggedInUser;
  TextEditingController _controller = TextEditingController();
  String data = "";
  FirebaseFirestore _firestore = FirebaseFirestore.instance;
  FirebaseStorage _storage = FirebaseStorage.instance;
  final picker = ImagePicker();

  final BannerAd myBanner = BannerAd(
    adUnitId: 'ca-app-pub-5785322248556811/9457730925',
    // ad unit for testing: 'ca-app-pub-3940256099942544/6300978111',
    size: AdSize.banner,
    request: AdRequest(),
    // listener: BannerAdListener(),
    listener: BannerAdListener(
      onAdLoaded: (Ad ad) {
        print('$BannerAd is loaded.');
      },
      onAdFailedToLoad: (Ad ad, LoadAdError error) {
        print('$BannerAd failedToLoad: $error');
        ad.dispose();
      },
      onAdOpened: (Ad ad) => print('$BannerAd ad is clicked.'),
      onAdClosed: (Ad ad) => print('$BannerAd ad is closed.'),
    ),
  );
 RewardedAd? rewardedAd;
  Timer ?_timer;
  int _start = 10;

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();

            rewardedAd?.show(onUserEarnedReward: (ad,item){});
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    rewardedAd?.dispose();
    myBanner.dispose();
    super.dispose();
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentUser();
    myBanner.load();


    RewardedAd.load(
        adUnitId: 'ca-app-pub-5785322248556811/8953607542',
        request: AdRequest(),
    rewardedAdLoadCallback: RewardedAdLoadCallback(
    onAdLoaded: (RewardedAd ad) {
    print('$ad loaded.');
    // Keep a reference to the ad so you can show it later.
    rewardedAd = ad;
    },
    onAdFailedToLoad: (LoadAdError error) {
    print('RewardedAd failed to load: $error');
    },
    ));
startTimer();

  }

  void getCurrentUser() async {
    if (_auth.currentUser == null) {
      Navigator.pop(context);
    }else{
      final user = _auth.currentUser!;
      loggedInUser = user;
      print(loggedInUser.email);
    }

  }

  Future uploadPic() async {
    //Get the file from the image picker and store it
    final _picker = ImagePicker();
    PickedFile? image = await _picker.getImage(source: ImageSource.gallery);
    //Create a reference to the location you want to upload to in firebase
    Uuid newImageId = new Uuid();
    final newName = newImageId.v4();
    print(newName);
    Reference reference = _storage.ref().child(newName);
    //Upload the file to firebase
    int flag = 0;
    UploadTask uploadTask = reference.putFile(File(image!.path));

    DateTime messageDate = DateTime.now();
    Timestamp imageStamp = Timestamp.fromDate(messageDate);
    // Waits till the file is uploaded then stores the download url
    uploadTask
      ..whenComplete(() => _firestore.collection("messages").add({
            'date': imageStamp,
            'message': null,
            'sentImage':
                'https://firebasestorage.googleapis.com/v0/b/friendly-d7b47.appspot.com/o/' +
                    newName +
                    '?alt=media',
            'name': loggedInUser.displayName,
            'photoUrl': loggedInUser.photoURL,
            'email': loggedInUser.email,
          }));

    //returns the download url
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    GoogleSignIn _googleSignIn = GoogleSignIn();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xffA4D65D),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
                child: Align(
                    alignment: Alignment.topRight, child: Text(widget.title))),
            Container(
              width: size.width * 0.38,
              child: Align(
                alignment: Alignment.topRight,
                child: FlatButton(
                    onPressed: () => showDialog<String>(
                        context: context,
                        builder: (BuildContext context) => Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: size.width * 0.1,
                                  vertical: size.height * 0.15),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xffA4D65D).withOpacity(0.85),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Row(
                                        children: [
                                          Expanded(
                                              child: Align(
                                                  alignment: Alignment.topRight,
                                                  child: GestureDetector(
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                      },
                                                      child: Icon(
                                                        Icons.clear,
                                                        color: Colors.white,
                                                        size: size.width * 0.08,
                                                      ))))
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: size.width * 0.1),
                                      child: Container(
                                        height: size.height * 0.5,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text(
                                              "Logging Out?",
                                              style: TextStyle(
                                                fontSize: size.width * 0.07,
                                                color: Colors.white,
                                                decoration: TextDecoration.none,
                                              ),
                                            ),
                                            Column(
                                              children: [
                                                Text(
                                                  "Your data will be saved\n",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize:
                                                        size.width * 0.025,
                                                    color: Colors.white,
                                                    decoration:
                                                        TextDecoration.none,
                                                  ),
                                                ),
                                                Text(
                                                  "See you again!",
                                                  style: TextStyle(
                                                    fontSize:
                                                        size.width * 0.025,
                                                    color: Colors.white,
                                                    decoration:
                                                        TextDecoration.none,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                _auth.signOut();
                                                _googleSignIn.signOut();
                                                _timer?.cancel();
                                                rewardedAd?.dispose();
                                                myBanner.dispose();

                                                Navigator.pushNamed(
                                                    context, '/home');
                                              },
                                              child: Container(
                                                width: size.width * 0.4,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            40),
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                        color: Colors.white,
                                                        width: 1)),
                                                child: Center(
                                                  child: Container(
                                                    padding: EdgeInsets.all(20),
                                                    child: Text(
                                                      'Logout',
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: size.width *
                                                              0.042,
                                                          decoration:
                                                              TextDecoration
                                                                  .none),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )),
                    child: Text(
                      'LogOut',
                      style: TextStyle(fontSize: 12, color: Colors.white),
                    )),
              ),
            ),
          ],
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          StreamBuilder<QuerySnapshot>(
              stream:
                  _firestore.collection("messages").orderBy('date').snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final messages = snapshot.data;
                  List<messageCard> messageWidgets = [];

                  for (var message in messages!.docs.reversed) {
                    var text = message["message"];
                    var msgStamp = message["date"];
                    var msgDate = msgStamp.toDate().day.toString();
                    var msgMonth = DateFormat('MMMM').format(msgStamp.toDate());
                    var msgYear = msgStamp.toDate().year.toString();
                    var photoUrl = message["photoUrl"];
                    var name = message["name"];
                    var email = message["email"];
                    var sentImage = message["sentImage"];
                    final messageWidget = messageCard(
                      text: text,
                      date: msgDate,
                      month: msgMonth,
                      year: msgYear,
                      photoUrl: photoUrl,
                      name: name,
                      email: email,
                      loggedInEmail: loggedInUser.email,
                      sentImage: sentImage,
                    );
                    messageWidgets.add(messageWidget);
                  }

                  return Expanded(
                    child: ListView(
                      reverse: true,
                      padding: EdgeInsets.all(size.width * 0.05),
                      children: messageWidgets,
                    ),
                  );
                } else {
                  return Container();
                }
              }),
          Container(
            child: Row(
              children: [
                Expanded(
                  child: Container(
                      height: size.height * 0.08,
                      color: Color(0xffECECEC),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Container(
                                  child: GestureDetector(
                                onTap: () {
                                  uploadPic();
                                },
                                child: Icon(
                                  Icons.add_photo_alternate_outlined,
                                  color: Color(0xffE76423),
                                ),
                              )),
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  border: Border.all(color: Color(0xffC5C5C5)),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8.0),
                                  child: TextField(
                                    onChanged: (value) {
                                      data = value;
                                    },
                                    controller: _controller,
                                    maxLines: 100,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      focusedBorder: InputBorder.none,
                                      enabledBorder: InputBorder.none,
                                      errorBorder: InputBorder.none,
                                      disabledBorder: InputBorder.none,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            GestureDetector(
                                onTap: () {
                                  DateTime messageDate = DateTime.now();
                                  Timestamp messageStamp =
                                      Timestamp.fromDate(messageDate);
                                  if (data != "") {
                                    _firestore.collection("messages").add({
                                      'message': data,
                                      'date': messageStamp,
                                      'name': loggedInUser.displayName,
                                      'photoUrl': loggedInUser.photoURL,
                                      'email': loggedInUser.email,
                                      'sentImage': null,
                                    });
                                  }
                                  _controller.clear();
                                  data = "";
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Icon(Icons.send),
                                )),
                          ],
                        ),
                      )),
                ),
              ],
            ),
          ),
          Container(
            height: 50.0,
            child: AdWidget(ad: myBanner),
          ),
        ],
      ),
      // Row(
      //   children: [
      //     Expanded(
      //       child: Container(
      //           color: Colors.red,
      //           child: Row(
      //             children: [
      //               Icon(Icons.add_photo_alternate_outlined),
      //               Expanded(
      //                 child: Container(
      //                   child: TextField(
      //
      //                   ),
      //                 ),
      //               ),
      //               Icon(Icons.send),
      //             ],
      //           )
      //       ),
      //     ),
      //   ],
      // )
    );
  }
}

class messageCard extends StatefulWidget {
  messageCard(
      {this.date,
      this.text,
      this.month,
      this.year,
      this.email,
      this.name,
      this.photoUrl,
      this.loggedInEmail,
      this.sentImage});
  final text;
  final date;
  final month;
  final year;
  final photoUrl;
  final email;
  final name;
  final loggedInEmail;
  final sentImage;

  @override
  _messageCardState createState() => _messageCardState();
}

class _messageCardState extends State<messageCard> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Row(
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: size.height * 0.02),
          child: Container(
            height: size.height * 0.05,
            width: size.width * 0.1,
            decoration: widget.photoUrl == null ? BoxDecoration() :  BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.black),
              image: DecorationImage(
                image:
                     NetworkImage(
                        widget.photoUrl,
                      )
                    ,
              ),
            ),
            child: widget.photoUrl != null
                ? Padding(
                    padding: const EdgeInsets.all(7.0),
                  )
                : Icon(Icons.person),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: widget.email == widget.loggedInEmail
                            ? Colors.blue
                            : Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 20.0,
                          ),
                        ],
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: widget.sentImage == null
                                ? const EdgeInsets.all(14.0)
                                : const EdgeInsets.all(8.0),
                            child: widget.sentImage == null
                                ? Text(
                                    widget.text??"",
                                    style: TextStyle(
                                        color:
                                            widget.email == widget.loggedInEmail
                                                ? Colors.white
                                                : Colors.black,
                                        fontSize: size.width * 0.04),
                                  )
                                : Container(
                                    color: Colors.red,
                                    width: size.width * 0.5,
                                    child: Image(
                                      image: NetworkImage(
                                        widget.sentImage,
                                      ),
                                    )),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    widget.name??"",
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
